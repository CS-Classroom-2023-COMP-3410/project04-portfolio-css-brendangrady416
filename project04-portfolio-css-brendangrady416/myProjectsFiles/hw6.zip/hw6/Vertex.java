package hw6;

import java.util.ArrayList;

public class Vertex implements Comparable<Vertex>{
	
	String word;
	int distance;
	Vertex pred;
	ArrayList<String > neighbors;
	
	//Vertex holds the word, the word's distance, its predecessor, and a list of its neighbors 
	public Vertex(String word, int dist, Vertex pred, ArrayList<String > neighbors) {
		this.word = word;
		this.distance = dist;
		this.pred = pred;
		this.neighbors = neighbors;
	}
	
	//setters for all instance variables 
	public void setWord(String newWord) {
		this.word = newWord;
	}
	
	public void setDistance(int newDist) {
		this.distance = newDist;
	}
	
	public void setPred(Vertex newPred) {
		this.pred = newPred;
	}
	
	public void setNeigh(ArrayList<String > newNeighbors) {
		this.neighbors = newNeighbors;
	}
	
	//returns the predecessor as a string of the word
	public String getPred() {
		if (this.pred == null) {
			return null;
		}
		return this.pred.word;
	}
	
	public String toString() {
	      return "["+ this.word + ", " + this.distance + ", " + this.getPred() +"]";
	}

	@Override
	public int compareTo(Vertex other) {
		return this.distance - other.distance;
	}
	
}

