package hw6;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Scanner;
import java.util.PriorityQueue;


public class WordPath {

	//Construct the graph from the dictionary using a hashtable
	//each word is a key linked to the vertex that word is on 
    public static void buildGraph(Hashtable<String, Vertex > adjList){
    	try { //file not found check 
			File f = new File("Dict.txt");
			Scanner sc = new Scanner(f);
				
			String word = new String();

			while (sc.hasNextLine()) {
				word = sc.nextLine().strip();
				//insert the word to the hashtable with a default vertex
				adjList.put(word, new Vertex(word, 1000000, null, new ArrayList<String >() ) );
				}
				
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
    	
    	//Check all possible word variations and add unique real words to the graph
    	for (String baseWord: adjList.keySet()) {
    		for (int i=0; i< baseWord.length(); i++) {
				String tempWord = baseWord;
    			for(char alphabet = 'a'; alphabet <='z'; alphabet ++ ) {
    				if (i==0) {
    					tempWord = alphabet +baseWord.substring(1, baseWord.length());
    				}
    				else if(i == baseWord.length()) {
    					tempWord = baseWord.substring(0,i) +alphabet ;
    				}
    				else {
    					tempWord = baseWord.substring(0,i) +alphabet +baseWord.substring(i+1, baseWord.length());
    				}
    				
					//Check if this new string is a real word, is not the base word, and is not already in the neighbors list 
    				if (adjList.containsKey(tempWord) && !(tempWord.equals(baseWord))  && !(adjList.get(baseWord).neighbors.contains( tempWord ))) {
    					adjList.get(baseWord).neighbors.add(tempWord);
    				}
    			}
    		}
    	}
    }
    
    //find the distance between two words by ascii value 
    public static int FindDistance(Vertex vertex1, Vertex vertex2) {
    	int difference = 0;
    	for (int i=0; i<vertex1.word.length(); i++) {
    		difference += (int) (vertex2.word.toLowerCase().charAt(i) - vertex1.word.toLowerCase().charAt(i));
    	}
    	return Math.abs(difference);
    }
    
    
    //Dijkstra algorithm
    public static void Dijkstra(Hashtable<String, Vertex > adjList, String startWord, String endWord) {
    	//Check that input words exist in the dictionary
    	if ( !(adjList.containsKey(startWord)) || !(adjList.containsKey(endWord))) {
    		System.out.println("Word not found");
    		return;
    	}
    	else if ( endWord.equals(startWord) ) {
    		System.out.println("Start and end words are the same, distance of 0 ");
    		return;
    	}
    	
    	//create new priority-queue with the start word as the first vertex with a distance of 0 
    	VertexComparator comp = new VertexComparator();
    	PriorityQueue<Vertex> priQueue = new PriorityQueue<>(11, comp);
    	priQueue.add(new Vertex(startWord, 0, null, adjList.get(startWord).neighbors ) ); 
    	
    	//for every word on the graph, add to the queue if word is the same size as the start word 
    	for (String baseWord: adjList.keySet()) {
    		if (baseWord.length() == startWord.length() && !(baseWord.equals(startWord))) {
    			priQueue.add(adjList.get(baseWord));   		
    		}
    	}
    	
    	//A list to store the vertexes removed from the queue 
    	ArrayList<Vertex> finalList = new ArrayList<Vertex >();

    	//loop until all vertexes are pulled from the queue, or the stopWord is pulled 
    	while (priQueue.size() > 0) {  
    		
    		Vertex vertexU = priQueue.poll();  		
    		finalList.add(vertexU );
    		
    		//If the target word was removed, return the path and list and end the loop 
    		if (vertexU.word.equals(endWord) ) {
    			System.out.println("Word: "+ vertexU.word + ", Distance: " + vertexU.distance + ", Predecessor: " + vertexU.pred.word);
    	    	System.out.println("Final list of vertexes pulled from the queue: " + finalList);
    	    	PrintPath(finalList, endWord);
    			return;
    		}

    		for (String wordV: vertexU.neighbors ) {	
    			Vertex vertexV = adjList.get(wordV);
    			Vertex newVertexV = vertexV; 
    			
    			//Relax the distance and update all instances of the vertexes    			 			
    			if (Math.abs(vertexU.distance + FindDistance(vertexU, vertexV)) < Math.abs(vertexV.distance) ) {			
    				newVertexV.setDistance(Math.abs( vertexU.distance + FindDistance(vertexU, vertexV)) );   				
    				newVertexV.setPred(vertexU); 	
    				priQueue.remove(vertexV);
    				priQueue.add(newVertexV);
    	    	}    			
    		}   		
    	}
    	//output final list with final distances 
    	System.out.println("No path found ");
    	
    }
    
    //Output the path from start to end word
    public static void PrintPath(ArrayList<Vertex> finalList, String endWord) {
    	String currentWord = endWord;
    	ArrayList<Vertex> path = new ArrayList<Vertex>();
    	//loop backwards through the final list to get correct order of words
    	for (int i = finalList.size() -1; i >=0; i--) {
    		if (finalList.get(i).word.equals(currentWord) ) {
    			path.add(0, finalList.get(i));
    			currentWord = finalList.get(i).getPred();
    		}
    	}
    	System.out.println("Complete path from start to end words: "+ path);
    }
       
    
    
    public static void FindPath(String startWord, String endWord, Hashtable< String, Vertex> adjList){
    	//Run the Dijkstra path finding method 
 	    Dijkstra(adjList, startWord, endWord);
    }
        
    
}
