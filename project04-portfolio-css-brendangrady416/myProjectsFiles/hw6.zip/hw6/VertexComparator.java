package hw6;

import java.util.Comparator;

public class VertexComparator implements Comparator<Vertex>{

	//Allows Vertexes to be compared in the priority-queue 
	@Override
	public int compare(Vertex o1, Vertex o2) {
		return o1.distance - o2.distance;
	}
	


}
