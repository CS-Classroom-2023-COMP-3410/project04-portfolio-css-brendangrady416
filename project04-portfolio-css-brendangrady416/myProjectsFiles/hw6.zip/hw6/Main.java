package hw6;

import java.util.Hashtable;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
	    Scanner sc = new Scanner(System.in); 
	    
	    //take user input words to find the path between
    	System.out.println("Enter new words. ");
    	System.out.println("Enter word 1: ");
	    String startWord = sc.nextLine();
	    
	    System.out.println("Enter word 2: ");
	    String endWord = sc.nextLine();
	    
	    //build the graph
	    //this is only done once 
	    Hashtable< String, Vertex> adjList = new Hashtable<String, Vertex >();
	    WordPath.buildGraph(adjList);
	    //check that the words are the same length before running Dijkstra
	    if (startWord.length() != endWord.length()) {
    		System.out.println("No path exists");
    	}
    	else {
    		WordPath.FindPath(startWord, endWord, adjList);
    	}

	    //Ask again
	    System.out.println("\nEnter new words. ");
    	System.out.println("Enter word 1: ");
	    startWord = sc.nextLine();
	    
	    System.out.println("Enter word 2: ");
	    endWord = sc.nextLine();
	   
	    //game loop
	    while (!(startWord.equals("STOP")) && !(endWord.equals("STOP")) ) {    
	    	if (startWord.length() != endWord.length()) {
	    		System.out.println("No path exists");
	    	}
	    	else {
	    		 WordPath.FindPath(startWord, endWord, adjList);
	    	}

	    	System.out.println("\nEnter new words. ");
	    	System.out.println("Enter word 1: ");
    	    startWord = sc.nextLine();
    	    
    	    System.out.println("Enter word 2: ");
    	    endWord = sc.nextLine();
	    }
    	
	}

}
