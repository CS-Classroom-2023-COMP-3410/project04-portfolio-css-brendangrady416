#include <stdio.h>
#include "Memory.h"

Memory::Memory(int size) {
    this->size = size;
    this->mainMemory = new unsigned char[size];
    for (unsigned char i = 0; i < size; i++) {
        this->mainMemory[i] = i ;
    }
}

//given an address, return the byte stored at that address
unsigned char Memory::getByte(unsigned long address) {
    if (address >= 0 && address < this->size) {
        return this->mainMemory[address];
    } else {
        return 0;
    }
}

//given an address and a value, set the byte at that address to the value
void Memory::setByte(unsigned long address, unsigned char value) {
    if (address >= 0 && address < this->size) {
        this->mainMemory[address] = value;
    }
}

//returns size of the memory
int Memory::getSize() {
    return this->size;
}

//outputs the memory contents in hex
void Memory::display() {
    for (unsigned long i = 0; i < this->size; i++) {
        printf("%02x ", this->mainMemory[i]);

        if ((i + 1) % 16 == 0) {
            printf("\n");
        }
    }
}