Brendan Grady

All code is working correctly as intended. Thank you for this quarter. 

Output: 

-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
Cache Simulator Nway Detialed Test
00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f 
10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f 
CACHE:
 Set 0
  Blocks:
  Block 0: 
   valid: 0   tag: 0   dirty: 0   Timestamp: 0
   00 00 00 00 
  Block 1: 
   valid: 0   tag: 0   dirty: 0   Timestamp: 0
   00 00 00 00 
 Set 1
  Blocks:
  Block 0: 
   valid: 0   tag: 0   dirty: 0   Timestamp: 0
   00 00 00 00 
  Block 1: 
   valid: 0   tag: 0   dirty: 0   Timestamp: 0
   00 00 00 00 
Accesses: 0
Hits: 0
Misses: 0
Writebacks: 0
Miss Percentage: 0
Miss Writeback Percentage: 0
-------------------------------------------------------------------
READ 0
0
00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f 
10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f 
CACHE:
 Set 0
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387117245
   00 01 02 03 
  Block 1: 
   valid: 0   tag: 0   dirty: 0   Timestamp: 0
   00 00 00 00 
 Set 1
  Blocks:
  Block 0: 
   valid: 0   tag: 0   dirty: 0   Timestamp: 0
   00 00 00 00 
  Block 1: 
   valid: 0   tag: 0   dirty: 0   Timestamp: 0
   00 00 00 00 
Accesses: 1
Hits: 0
Misses: 1
Writebacks: 0
Miss Percentage: 100
Miss Writeback Percentage: 0
-------------------------------------------------------------------
READ 2
2
00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f 
10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f 
CACHE:
 Set 0
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387277126
   00 01 02 03 
  Block 1: 
   valid: 0   tag: 0   dirty: 0   Timestamp: 0
   00 00 00 00 
 Set 1
  Blocks:
  Block 0: 
   valid: 0   tag: 0   dirty: 0   Timestamp: 0
   00 00 00 00 
  Block 1: 
   valid: 0   tag: 0   dirty: 0   Timestamp: 0
   00 00 00 00 
Accesses: 2
Hits: 1
Misses: 1
Writebacks: 0
Miss Percentage: 50
Miss Writeback Percentage: 0
-------------------------------------------------------------------
READ 4
4
00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f 
10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f 
CACHE:
 Set 0
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387277126
   00 01 02 03 
  Block 1: 
   valid: 0   tag: 0   dirty: 0   Timestamp: 0
   00 00 00 00 
 Set 1
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387425425
   04 05 06 07 
  Block 1: 
   valid: 0   tag: 0   dirty: 0   Timestamp: 0
   00 00 00 00 
Accesses: 3
Hits: 1
Misses: 2
Writebacks: 0
Miss Percentage: 66
Miss Writeback Percentage: 0
-------------------------------------------------------------------
READ 10
10
00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f 
10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f 
CACHE:
 Set 0
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387277126
   00 01 02 03 
  Block 1: 
   valid: 1   tag: 1   dirty: 0   Timestamp: 1717814797387572527
   08 09 0A 0B 
 Set 1
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387425425
   04 05 06 07 
  Block 1: 
   valid: 0   tag: 0   dirty: 0   Timestamp: 0
   00 00 00 00 
Accesses: 4
Hits: 1
Misses: 3
Writebacks: 0
Miss Percentage: 75
Miss Writeback Percentage: 0
-------------------------------------------------------------------
READ 12
12
00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f 
10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f 
CACHE:
 Set 0
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387277126
   00 01 02 03 
  Block 1: 
   valid: 1   tag: 1   dirty: 0   Timestamp: 1717814797387572527
   08 09 0A 0B 
 Set 1
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387425425
   04 05 06 07 
  Block 1: 
   valid: 1   tag: 1   dirty: 0   Timestamp: 1717814797387719234
   0C 0D 0E 0F 
Accesses: 5
Hits: 1
Misses: 4
Writebacks: 0
Miss Percentage: 80
Miss Writeback Percentage: 0
-------------------------------------------------------------------
READ 1
1
00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f 
10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f 
CACHE:
 Set 0
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387865780
   00 01 02 03 
  Block 1: 
   valid: 1   tag: 1   dirty: 0   Timestamp: 1717814797387572527
   08 09 0A 0B 
 Set 1
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387425425
   04 05 06 07 
  Block 1: 
   valid: 1   tag: 1   dirty: 0   Timestamp: 1717814797387719234
   0C 0D 0E 0F 
Accesses: 6
Hits: 2
Misses: 4
Writebacks: 0
Miss Percentage: 66
Miss Writeback Percentage: 0
-------------------------------------------------------------------
READ 16
16
00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f 
10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f 
CACHE:
 Set 0
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387865780
   00 01 02 03 
  Block 1: 
   valid: 1   tag: 2   dirty: 0   Timestamp: 1717814797388011263
   10 11 12 13 
 Set 1
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387425425
   04 05 06 07 
  Block 1: 
   valid: 1   tag: 1   dirty: 0   Timestamp: 1717814797387719234
   0C 0D 0E 0F 
Accesses: 7
Hits: 2
Misses: 5
Writebacks: 0
Miss Percentage: 71
Miss Writeback Percentage: 0
-------------------------------------------------------------------
WRITE 6
00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f 
10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f 
CACHE:
 Set 0
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387865780
   00 01 02 03 
  Block 1: 
   valid: 1   tag: 2   dirty: 0   Timestamp: 1717814797388011263
   10 11 12 13 
 Set 1
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 1   Timestamp: 1717814797388156539
   04 05 06 07 
  Block 1: 
   valid: 1   tag: 1   dirty: 0   Timestamp: 1717814797387719234
   0C 0D 0E 0F 
Accesses: 8
Hits: 3
Misses: 5
Writebacks: 0
Miss Percentage: 62
Miss Writeback Percentage: 0
-------------------------------------------------------------------
WRITE 21
00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f 
10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f 
CACHE:
 Set 0
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387865780
   00 01 02 03 
  Block 1: 
   valid: 1   tag: 2   dirty: 0   Timestamp: 1717814797388011263
   10 11 12 13 
 Set 1
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 1   Timestamp: 1717814797388156539
   04 05 06 07 
  Block 1: 
   valid: 1   tag: 2   dirty: 1   Timestamp: 1717814797388300029
   14 15 16 17 
Accesses: 9
Hits: 3
Misses: 6
Writebacks: 0
Miss Percentage: 66
Miss Writeback Percentage: 0
-------------------------------------------------------------------
READ 12
00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f 
10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f 
CACHE:
 Set 0
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387865780
   00 01 02 03 
  Block 1: 
   valid: 1   tag: 2   dirty: 0   Timestamp: 1717814797388011263
   10 11 12 13 
 Set 1
  Blocks:
  Block 0: 
   valid: 1   tag: 1   dirty: 0   Timestamp: 1717814797388435429
   0C 0D 0E 0F 
  Block 1: 
   valid: 1   tag: 2   dirty: 1   Timestamp: 1717814797388300029
   14 15 16 17 
Accesses: 10
Hits: 3
Misses: 7
Writebacks: 1
Miss Percentage: 70
Miss Writeback Percentage: 10
-------------------------------------------------------------------
WRITE 30
00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f 
10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f 
CACHE:
 Set 0
  Blocks:
  Block 0: 
   valid: 1   tag: 0   dirty: 0   Timestamp: 1717814797387865780
   00 01 02 03 
  Block 1: 
   valid: 1   tag: 2   dirty: 0   Timestamp: 1717814797388011263
   10 11 12 13 
 Set 1
  Blocks:
  Block 0: 
   valid: 1   tag: 1   dirty: 0   Timestamp: 1717814797388435429
   0C 0D 0E 0F 
  Block 1: 
   valid: 1   tag: 3   dirty: 1   Timestamp: 1717814797388577201
   1C 1D 1E 1F 
Accesses: 11
Hits: 3
Misses: 8
Writebacks: 2
Miss Percentage: 72
Miss Writeback Percentage: 18