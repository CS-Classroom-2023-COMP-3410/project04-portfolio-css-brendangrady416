#include <stdio.h>
#include "PerformanceCounter.h"

PerformanceCounter::PerformanceCounter(){
    this->hits = 0;
    this->misses = 0;
    this->writebacks = 0;
    this->missPerc = 0;
    this->missWriteback = 0;
}

//increment hits
void PerformanceCounter::hit(){
    this->hits++;
}

//increment misses
void PerformanceCounter::miss(){
    this->misses++;
}

//increment writebacks
void PerformanceCounter::writeback(){
    this->writebacks++;
}

//display the performance counter's information
void PerformanceCounter::display(){
    printf("Accesses: %d\n", this->hits+this->misses);
    printf("Hits: %d\n", this->hits);
    printf("Misses: %d\n", this->misses);
    printf("Writebacks: %d\n", this->writebacks);
    if (this->hits + this->misses == 0){
        this->missPerc = 0;
    }
    else{
        this->missPerc = 100*((double)this->misses/(this->hits+this->misses));
    }
    printf("Miss Percentage: %d\n", this->missPerc);
    
    if (this->misses == 0){
        this->missWriteback = 0;
    }
    else{
        this->missWriteback = 100*(double)this->writebacks/(this->hits+this->misses);
    }    
    printf("Miss Writeback Percentage: %d\n", this->missWriteback);
}

