#include <stdio.h>

#include "Memory.h"
#include "Block.h"
#include "AddressDecoder.h"
#include "PerformanceCounter.h"

#include <chrono> // to bring in the chrono library

Block::Block(int blockSize, Memory* memory, AddressDecoder* decoder){
    this->blockSize = blockSize;
    this->data = new unsigned char[blockSize];
    for (unsigned char i = 0; i < blockSize; i++){
        data[i] = 0 ;
    }
    this->decoder = decoder;
    this->memory = memory;
    this->valid = 0;
    this->dirty = 0;  
    this->lru = 0;
    this->address ;
    this->tag = 0;

}

//update the time stamp 
void Block::getNanoSec(){
    std::chrono::high_resolution_clock m_clock;
    this->lru = std::chrono::duration_cast<std::chrono::nanoseconds>(m_clock.now().time_since_epoch()).count();
}

//read from the block at the correct byte
unsigned char Block::read(unsigned long offset) {
    getNanoSec();
    this->valid = 1;
    return memory->getByte(offset);
}

//write to the block at the correct byte
void Block::write(unsigned char value, unsigned long offset) {
    getNanoSec();
    this->dirty = 1;
    this->valid = 1;
    data[offset] = value;
}

//load the block from memory into data
void Block::loadFromMemory(unsigned long address){
    address = address - (address % this->blockSize);
    for (int i = 0; i < this->blockSize; i++){
        data[i] = this->memory->getByte(address + i);
    }
    this->dirty = 0;
}

//save the block back to memory
void Block::saveToMemory(unsigned long address){
    address = address - (address % this->blockSize);
    for (int i = 0; i < this->blockSize; i++){
        this->memory->setByte(i, i);
    }
}
//Getters
int Block::getLRU(){
    return this->lru;
}

int Block::getValid(){
    return this->valid;
}

int Block::getDirty(){
    return this->dirty;
}

unsigned long Block::getTag(){
    return this->tag;
}

//Setters
void Block::setDirty(int value){
    this->dirty = value;
}

void Block::setValid(int value){
    this->valid = value;
}

void Block::setTag(unsigned long tag){
    this->tag = tag;
}

//display the block and its contents
void Block::display(){
    printf("   valid: %d  ", this->valid);
    printf(" tag: %lu  ", this->tag);
    printf(" dirty: %d  ", this->dirty);
    printf(" Timestamp: %ld\n   ", this->lru);

    for (int i = 0; i < blockSize; i++) {
        printf("%02X ", data[i]);
    }
    printf("\n");
}