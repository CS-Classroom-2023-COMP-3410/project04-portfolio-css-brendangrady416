#include "Memory.h"

#ifndef ADDRESSDECODER_H
#define ADDRESSDECODER_H

class AddressDecoder {
    private:
        unsigned long address;
        Memory* memory;
        int blockSize;
        int numSets;
        int setAsso;
        int blockOffsetBits;
        int setIndexBits;
        
    public:
        AddressDecoder(Memory* memeory, int blockSize, int numSets, int setAsso);
        unsigned long getTag(unsigned long address);
        unsigned long getSetIndex(unsigned long address);
        unsigned long getBlockOffset(unsigned long address);
        unsigned long getBaseAddress(unsigned long tag, unsigned long address);
};

#endif