#include "Block.h"
#include "AddressDecoder.h"
#include "PerformanceCounter.h"

#ifndef SET_H
#define SET_H

class Set {
    private:
        int blockSize;
        int numBlocks;
        Block** blocks;
        Memory* memory;
        AddressDecoder* decoder;
        PerformanceCounter* performanceCounter;
        
    public:
        Set(int blockSize, int numBlocks, Memory* memory, AddressDecoder* decoder, PerformanceCounter* performanceCounter);
        unsigned char read(unsigned long address);
        void write(unsigned long address, unsigned char value);
        unsigned long getID(unsigned long tag, unsigned long address);
        unsigned long findMatchingBlock(unsigned long tag, unsigned long address);
        unsigned long getEmptyBlock();
        unsigned long findLruBlock();
        void evictLruBlock(unsigned long address, int lruBlock);
        void display();
};

#endif