#include <stdio.h> 

#include "Memory.h"
#include "Block.h"
#include "AddressDecoder.h"
#include "Set.h"
#include "PerformanceCounter.h"

Set::Set(int blockSize, int numBlocks, Memory* memory, AddressDecoder* decoder, PerformanceCounter* performanceCounter){
    this->blockSize = blockSize;
    this->numBlocks = numBlocks;
    this->blocks = new Block*[numBlocks];
    for (int i = 0; i < numBlocks; i++){
        this->blocks[i] = new Block(this->blockSize, memory, decoder);
    }
    this->memory = memory;
    this->decoder = decoder;
    this->performanceCounter = performanceCounter;
}

//read the cache at the correct block 
unsigned char Set::read(unsigned long address){
    unsigned long tag = this->decoder->getTag(address);
    //get the index of the block using the helper functions
    unsigned long id = getID(tag, address);
    //call Block read function
    return this->blocks[id]->read(this->decoder->getBlockOffset(address));
}

//write to the cache at the correct block
void Set::write(unsigned long address, unsigned char value){
    unsigned long tag = this->decoder->getTag(address);
    //get the index of the block using the helper functions
    unsigned long id = getID(tag, address);
    //call Block write function
    this->blocks[id]->write(this->decoder->getBlockOffset(address), value);
}

//Helper function to get the ID of the block to read and write to
unsigned long Set::getID(unsigned long tag, unsigned long address) {
    unsigned long index;
    //find the index of the block that matches the tag
    unsigned long matchIndex = findMatchingBlock(tag, address);
    if (matchIndex != -1) {
        //if the block is used and the tag matches, it is a hit
        this->performanceCounter->hit();
        index = matchIndex;
    }
    else{
        //no matching blocks are found, miss
        //find an empty block to put the new information in
        unsigned long emptyIndex = getEmptyBlock();
        if (emptyIndex != -1) {
            //initialize the empty block into the set and assign all values 
            unsigned long tag = this->decoder->getTag(address);
            unsigned long blockAddress = this->decoder->getBaseAddress(tag, address);
            this->blocks[emptyIndex]->loadFromMemory(blockAddress);
            this->blocks[emptyIndex]->setTag(tag);
            this->blocks[emptyIndex]->setValid(0);
            this->blocks[emptyIndex]->getNanoSec();
            this->performanceCounter->miss();
            index = emptyIndex;
        }
        else{
            //no empty blocks are found 
            //find the LRU block
            unsigned long lruBlock = findLruBlock();
            //evict the lru block
            evictLruBlock(address, lruBlock);
            this->performanceCounter->miss();
            index = lruBlock;
        }
    }
    //return the index of the block to read or write to
    return index;
}

//get the index of a matching block
unsigned long Set::findMatchingBlock(unsigned long tag, unsigned long address) {
    //go through all the blocks in the set and find the used block that has this tag
    for (unsigned long i = 0; i < this->numBlocks; i++) {
        if (this->blocks[i]->getValid() && (this->blocks[i]->getTag() == tag)) {
            return i;
        }
    }
    //no matching blocks are found
    return -1;
}

//get the index of the first empty block
unsigned long Set::getEmptyBlock() {
    //go through all the blocks in the set and find the first empty block
    for (unsigned long i = 0; i < this->numBlocks; i++) {
        if (!(this->blocks[i]->getValid())) {
            return i;
        }
    }
    //no empty blocks are found
    return -1;
}

//get the least recently used block
unsigned long Set::findLruBlock() {
    unsigned long lruBlock = 0;
    //go through all the blocks in the set and find the block with the least recent timestamp
    for (unsigned long i = 1; i < this->numBlocks; i++){
        if (this->blocks[i]->getLRU() < this->blocks[lruBlock]->getLRU()){
            lruBlock = i;
        }
    }
    return lruBlock;
}

//evict the lru block
void Set::evictLruBlock(unsigned long address, int lruBlock) {
    //only save the lru block to memory if it is dirty
    if (this->blocks[lruBlock]->getDirty()) {
        unsigned long lruTag = this->blocks[lruBlock]->getTag();
        unsigned long blockAddress = this->decoder->getBaseAddress(lruTag, address);
        this->performanceCounter->writeback();
        this->blocks[lruBlock]->saveToMemory(blockAddress);
    }
    //load the new block into the lru block's location to replace it 
    unsigned long tag = this->decoder->getTag(address);
    unsigned long blockAddress = this->decoder->getBaseAddress(tag, address);
    this->blocks[lruBlock]->loadFromMemory(blockAddress);
    this->blocks[lruBlock]->setTag(tag);
    this->blocks[lruBlock]->setValid(0);
    this->blocks[lruBlock]->getNanoSec();
}


//output the set and call block display for each block
void Set::display(){
    printf("  Blocks:\n");
    for (int i = 0; i < this->numBlocks; i++){
        printf("  Block %d: \n", i);
        this->blocks[i]->display();
        
    }
}