#ifndef PERFORMANCECOUNTER_H
#define PERFORMANCECOUNTER_H

class PerformanceCounter {
    private:
        int hits;
        int misses;
        int writebacks;
        int missPerc;
        int missWriteback;
        
    public:
        PerformanceCounter();
        void hit();
        void miss();
        void writeback();
        void display();
        
        
};

#endif