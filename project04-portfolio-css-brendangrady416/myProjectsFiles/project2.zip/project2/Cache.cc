#include <stdio.h>

#include "Memory.h"
#include "Block.h"
#include "AddressDecoder.h"
#include "PerformanceCounter.h"
#include "Set.h"
#include "Cache.h"

Cache::Cache(Memory* memory, int cacheSize, int blockSize, int setAsso){
    this->memory = memory;
    this->cacheSize = cacheSize;
    this->blockSize = blockSize;
    this->setAsso = setAsso;
    //calculate number of sets
    this->numSets = cacheSize/(blockSize*setAsso); 
    this->decoder = new AddressDecoder(memory, blockSize, this->numSets, setAsso);
    this->performanceCounter = new PerformanceCounter();
    //create a cache filled with numSets number of set objects 
    this->cache = new Set*[this->numSets];
    for (int i = 0; i < this->numSets; i++){
        this->cache[i] = new Set(blockSize, setAsso, memory, decoder, this->performanceCounter);
    }
}

//read from the cache at the right index
unsigned char Cache::read(unsigned long address){
    unsigned long setIndex = decoder->getSetIndex(address);
    return cache[setIndex]->read(address);
}

//write to the cache at the right index
void Cache::write(unsigned long address, unsigned char value){
    unsigned long setIndex = decoder->getSetIndex(address);
    cache[setIndex]->write(address, value);
}

//output cache and call set display for each set
void Cache::display(){
    printf("CACHE:\n");
    for (int i = 0; i < this->numSets; i++){
        printf(" Set %d\n", i);
        this->cache[i]->display();
    }
    this->performanceCounter->display();
}
