#include "AddressDecoder.h"

#ifndef BLOCK_H
#define BLOCK_H

class Block {
    private:
        int blockSize;
        unsigned char* data;
        AddressDecoder* decoder;
        long lru;
        int valid;
        int dirty;
        unsigned long tag;
        Memory* memory;
        unsigned long address;
        
    public:
        Block(int blockSize, Memory* mem, AddressDecoder* decoder);
        unsigned char read(unsigned long offset);
        void write(unsigned char value, unsigned long offset);
        int getLRU();
        int getValid();
        int getDirty();
        void loadFromMemory(unsigned long address);
        void saveToMemory(unsigned long address);
        unsigned long getTag();
        void setDirty(int value);
        void setValid(int value);
        void setTag(unsigned long tag);
        void getNanoSec();
        void display();
};

#endif