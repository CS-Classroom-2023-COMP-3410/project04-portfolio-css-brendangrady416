#include <stdio.h>
#include <math.h>

#include "AddressDecoder.h"

AddressDecoder::AddressDecoder(Memory* memory, int blockSize, int numSets, int setAsso){
    this->memory = memory;

    this->blockSize = blockSize;
    this->numSets = numSets;
    this->setAsso = setAsso;
    this->blockOffsetBits = log2(blockSize);
    this->setIndexBits = log2(numSets);
}

//get the tag from the address
unsigned long AddressDecoder::getTag(unsigned long address){
    unsigned long addressTemp = address;
    return (addressTemp >> (blockOffsetBits + setIndexBits));
}

//get the set index from the address
unsigned long AddressDecoder::getSetIndex(unsigned long address){
    unsigned long addressTemp = address;
    unsigned long setIndex = (addressTemp >> blockOffsetBits) & ((1 << setIndexBits) - 1);
    return setIndex;
}

//get the block offset from the address
unsigned long AddressDecoder::getBlockOffset(unsigned long address){
    unsigned long addressTemp = address;
    return ( (addressTemp << (sizeof(address) - blockOffsetBits))) >> (sizeof(address) - blockOffsetBits);
}

//get the full address from the tag and address
unsigned long AddressDecoder::getBaseAddress(unsigned long tag, unsigned long address){
    tag = tag << setIndexBits;
    tag |= getSetIndex(address);
    tag = tag << blockOffsetBits;
    tag |= getBlockOffset(address);
    return tag;
}


