/*
 * Brendan Grady
 *MalformedTerrainFileException works as intended, there were no big issues 
 */

package hw3;

public class MalformedTerrainFileException extends TerrainFileException{
	public MalformedTerrainFileException(String message) {
		super (message);
	}
}
