/*
 * Brendan Grady
 *GridPoint works as intended, the only challenge was with getNeighbors, specifically in working around 
 * the window borders. 
 */

package hw3;

import java.util.ArrayList;
import java.util.List;

/*
 * Class to represent an x and y grid location.
 * 
 * TODO: Should have standard methods: equals, toString, hashCode, compareTo
 */
public class GridPoint implements Comparable<GridPoint>{
	
	private int x;
	private int y;
	
	public GridPoint(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	//return X value
	public int getX() {
		return this.x;
	}
	
	//return Y value 
	public int getY() {
		return this.y; 
	}
	
	// equals method for another GridPoint object
	public boolean equals(Object o) {
		if(o instanceof GridPoint){
	        GridPoint g = (GridPoint)o;
	        return (this.x == g.getX() && this.y == g.getY());
	    }
	    return false;
	}
	
	//print out coordinates 
	public String toString() {
		return "("+ this.x +", "+ this.y +")";
	}
	
	//hashcode coordinates 
	public int hashCode() {
		return (this.x +", "+ this.y).hashCode();
	}
	
	//compareTo method for another Gridpoint
	public int compareTo(GridPoint that)
	{	
		int result = this.x - that.getX();
		if (result == 0) {
			result = this.y - that.getY();
		}
		return result;
	}
	
	//return a list of the surrounding gridPoints based on what level away is input 
	public List<GridPoint> getNeighbors(int levels){
		List<GridPoint> gridList =new ArrayList<GridPoint>();

		if (this.x-(levels) >-1 && this.y-(levels)>-1 && this.y+(levels)<20) {
			for (int i=levels*-1; i <=levels; i++) {
				gridList.add(new GridPoint(this.x-(levels), this.y+(i))); //left side 
			}
		}
		if (this.x+(levels) < 30 && this.y-(levels)>-1 && this.y+(levels)<20) {
			for (int i=levels*-1; i <=levels; i++) {
				gridList.add(new GridPoint(this.x+(levels), this.y+(i))); //right side 
			}
		}
		if (this.y-(levels) > -1 && this.x-(levels)>-1 && this.x+(levels)<30) {
			for (int i=levels*-1; i <=levels; i++) {
				gridList.add(new GridPoint(this.x+(i), this.y-(levels))); //bottom side 
			}
		}
		if (this.y+(levels) < 20 && this.x-(levels)>-1 && this.x+(levels)<30) {
			for (int i=levels*-1; i <=levels; i++) {
				gridList.add(new GridPoint(this.x+(i), this.y+(levels))); //top side 
			}
		}
		// if cornered 
		if (this.x+levels>=30 && this.y+levels>=20 ) {
			gridList.add(new GridPoint(this.x-levels, this.y));
			gridList.add(new GridPoint(this.x, this.y-levels));
		}
		else if(this.x+levels>=30 && this.y-levels<=-1 ) {
			gridList.add(new GridPoint(this.x-levels, this.y));
			gridList.add(new GridPoint(this.x, this.y+levels));
		}
		else if(this.x-levels<=-1 && this.y-levels<=-1 ) {
			gridList.add(new GridPoint(this.x+levels, this.y));
			gridList.add(new GridPoint(this.x, this.y+levels));
		}
		else if(this.x-levels<=-1 && this.y+levels>=20 ) {
			gridList.add(new GridPoint(this.x+levels, this.y));
			gridList.add(new GridPoint(this.x, this.y-levels));
		}
		
		return gridList;
	}
}
