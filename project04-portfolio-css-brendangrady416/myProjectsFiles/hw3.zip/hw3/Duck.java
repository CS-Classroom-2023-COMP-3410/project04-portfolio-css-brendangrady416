/*
 * Brendan Grady
 *Duck works as intended to display and correctly move the Duck avatar. Only slight 
 * problems in deciding how to go about changing the duck from flying to swimming.
 */

package hw3;

import java.util.List;

public class Duck extends Avatar{

	private String pic;

	protected Duck(int xLoc, int yLoc, TerrainMap tm) {
		super(xLoc, yLoc, tm);
		this.pic = "hw3_duck_flying.png";
	}
	
	//set the duck image
	public String getImage() {
		return this.pic;
	}
	
	//move the duck in random motion 
	public void move() {
		List<GridPoint> surroundings = new GridPoint(xLoc, yLoc).getNeighbors(1);
		System.out.println(surroundings);
		
		int moveAt = (int) Math.round(Math.random()*surroundings.size());
		for (int i=0; i< surroundings.size(); i++) {
			if (i ==  moveAt) {
				this.xLoc = surroundings.get(i).getX();
				this.yLoc = surroundings.get(i).getY();
				
				this.updateImage();
				return;
			}
		}
	}

	//display the correct image based on the ducks action
	public void updateImage() {
		if (TerrainMap.theTiles.get(new GridPoint(xLoc, yLoc)).getWet(null)<50 ) {
			this.pic = "hw3_duck_flying.png";
		}
		else if (TerrainMap.theTiles.get(new GridPoint(xLoc, yLoc)).getWet(null)>=50 ) {
			this.pic = "hw3_duck_swimming.png";
		}
	}
	

}
