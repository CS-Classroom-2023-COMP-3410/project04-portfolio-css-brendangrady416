/*
 * Brendan Grady
 *TerrainTile works as intended, there were no big issues after I was able to use the setColor function 
 */

package hw3;

import edu.du.dudraw.Draw;

//This is an abstract class
public abstract class TerrainTile implements Drawable {
	
	// Every tile has a location
	private GridPoint location;
	
	protected TerrainTile (GridPoint location) {
		this.location = location;
	}

	// Draws the tile on the given Window
	public void draw(Draw duDwin) {

		// TODO: Get the derived class to set whatever color it wants by calling 
		// the abstract method.
		this.setColor(duDwin);
		
		// TODO: draw the tile in a standard way
		duDwin.filledRectangle(location.getX()* 35 +17.5, 700 - location.getY()*35 -17.5, 17, 17);
	}
	
	// Part of the draw template for concrete tiles to set the color
	public abstract void setColor(Draw duDwin);
	
	public abstract void setVeg(int v);
	
	public int getVeg(Draw duDwin) {
		return 0;
	}
	
	public int getWet(Draw duDwin){
		return 0;
	}
	
	public int getBumpy(Draw duDwin){
		return 0;
	}
	
}
