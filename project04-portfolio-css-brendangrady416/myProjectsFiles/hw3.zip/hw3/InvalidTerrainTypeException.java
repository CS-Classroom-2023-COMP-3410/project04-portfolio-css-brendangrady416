/*
 * Brendan Grady
 *InvalidTerrainTypeException works as intended, there were no big issues 
 */

package hw3;

public class InvalidTerrainTypeException extends TerrainFileException{
	public InvalidTerrainTypeException(String message) {
		super (message);
	}
}