/*
 * Brendan Grady
 *Main works as intended to initialize the terrain map as well as calling the avatar factory to make all the 
 * avatars and run the sim
 */

package hw3;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) throws InvalidTerrainTypeException, MalformedTerrainFileException {
		// Load in the map
		TerrainMap tm = new TerrainMap("map1.txt");

		List<Avatar> avas = new ArrayList<Avatar>();
		try {
			avas.add(AvatarFactory.newAvatar("Cow", tm, new GridPoint(15,2)) );
			avas.add(AvatarFactory.newAvatar("Cow", tm, new GridPoint(15,18)) );
			avas.add(AvatarFactory.newAvatar("Goat", tm, new GridPoint(15,7)) );
			avas.add(AvatarFactory.newAvatar("Duck", tm, new GridPoint(2,9)) );
			avas.add(AvatarFactory.newAvatar("Frog", tm, new GridPoint(6,3)) );
			avas.add(AvatarFactory.newAvatar("Human", tm, new GridPoint(0,19)) );
		} catch (BadAvatarException e) {
			e.printStackTrace();
		}
		
		// Make the display panel
		SimWindow window = new SimWindow(tm, avas);
		
		// Start the simulation
		window.runSimulation();
	}

}
