/*
 * Brendan Grady
 *Works as intended. I struggled to correctly catch the custom exceptions in the correct place.
 *I also could not get the HashMap to work right, I kept getting a package error, so you told me
 * to use a TreeMap instead. 
 */

package hw3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

import edu.du.dudraw.Draw;

// The TerrainMap represents a 2D grid of Tiles

public class TerrainMap implements Drawable {

	static Map<GridPoint, TerrainTile> theTiles;
	
	// public static constants set in the constructor.
	public static int gridWidth;
	public static int gridHeight;

	// Constructor to read from file
	public TerrainMap(String filename) throws InvalidTerrainTypeException, MalformedTerrainFileException {
		// TODO: Read the map specified by `filename` and add
		// TerrainTile objects (based on the terrain type specified by the map)
		// to theTiles.œ
		
		// TODO: make sure you set gridWidth and gridHeight static data members when you 
		// read the map.
		
		TerrainMap.theTiles = new TreeMap<GridPoint, TerrainTile>();
		
		try { //file not found check 
			File f = new File(filename);
			Scanner sc = new Scanner(f);
			
			try {
				TerrainMap.gridWidth = Integer.valueOf(sc.next());
				TerrainMap.gridHeight = Integer.valueOf(sc.next());
				
			} catch (NumberFormatException e){
				throw new MalformedTerrainFileException("Malformed Terrain File");
			}
				
			String letter = new String();
			
			//Loop through the given map and add each location and tile type to the theTiles Map
			for (int i=0; i < TerrainMap.gridHeight; i++) {
				sc.nextLine();
				for (int j=0; j < TerrainMap.gridWidth; j++) {
					letter = sc.next();
					
					TerrainTileFactory.newTerrainTile(letter, new GridPoint(j, i));
						
					}
				}
				
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	//Draw all tiles from the theTiles Map 
	public void draw(Draw duDwin) {
		// TODO: cause each of the TerrainTile objects to draw itself.
		for (GridPoint point: this.theTiles.keySet()) {
			this.theTiles.get(point).draw(duDwin);
		}	
	}
	
	//return the wet value of a tile
	public int getWet(GridPoint loc){
		return this.theTiles.get(loc).getWet(null);
	}
	
	//return the vegitation value of a tile
	public int getVeg(GridPoint loc){
		return this.theTiles.get(loc).getVeg(null);
	}
	
	//return the bumpy level of a tile 
	public int getBumpy(GridPoint loc){
		return this.theTiles.get(loc).getBumpy(null);
	}

}
