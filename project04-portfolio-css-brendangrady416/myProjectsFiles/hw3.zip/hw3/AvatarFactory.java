/*
 * Brendan Grady
 *AvatarFactory works as intended, creating an avatar based on the given name and location
 */

package hw3;

public class AvatarFactory {
	public static Avatar newAvatar(String avaName, TerrainMap tm, GridPoint loc) throws BadAvatarException {
		
		if (avaName.equals("Cow")) {
			return new Cow(loc.getX(), loc.getY(), tm);
		}
		else if (avaName.equals("Goat")) {
			return new Goat(loc.getX(), loc.getY(), tm);
		}
		else if (avaName.equals("Duck")) {
			return new Duck(loc.getX(), loc.getY(), tm);
		}
		else if (avaName.equals("Frog")) {
			return new Frog(loc.getX(), loc.getY(), tm);
		}
		else if (avaName.equals("Human")) {
			return new Human(loc.getX(), loc.getY(), tm);
		}
		else {
			throw new BadAvatarException("Bad Avatar");
		}
	}

}