/*
 * Brendan Grady
 *Avatar class works correctly. It constructs all avatars, draws avatars, and establishes abstract methods
 */

package hw3;

import edu.du.dudraw.Draw;

public abstract class Avatar implements Drawable{
	
	public int xLoc;
	public int yLoc;
	private TerrainMap tm;
	
	
	protected Avatar(int xLoc, int yLoc, TerrainMap tm) {
		this.xLoc = xLoc;
		this.yLoc = yLoc;
		this.tm = tm;
		
	}
	
	//Draw avatars to the screen based on location and their correct image 
	public void draw(Draw DuDwin) {
		String image = this.getImage();
		DuDwin.picture(this.xLoc*35+17.5, (20-this.yLoc)*35-17.5, image, 35, 35);
	}
	
	//process mouse clicks. Used in Human class
	public void process(GridPoint end) {
		return;
	}
	
	public abstract void move();
	
	public abstract String getImage();

}
