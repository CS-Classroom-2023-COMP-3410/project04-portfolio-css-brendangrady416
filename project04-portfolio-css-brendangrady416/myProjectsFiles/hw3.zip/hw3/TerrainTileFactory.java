/*
 * Brendan Grady
 * Create a new terrainTile based on the input and add it to the TerrainMap with its location 
 */

package hw3;

public class TerrainTileFactory {
	public static TerrainTile newTerrainTile(String tileStr, GridPoint loc) throws InvalidTerrainTypeException {
		
		if (tileStr.equals("g")) {
			return TerrainMap.theTiles.put(loc ,new Grass(loc));
		}
		else if (tileStr.equals("w")) {
			return TerrainMap.theTiles.put(loc ,new Water(loc));
		}
		else if (tileStr.equals("r")) {
			return TerrainMap.theTiles.put(loc ,new Road(loc));
		}
		else if (tileStr.equals("m")) {
			return TerrainMap.theTiles.put(loc ,new Mountain(loc));
		}
		else {
			throw new InvalidTerrainTypeException("Invalid Terrain Type");
		}
		
	}

}
