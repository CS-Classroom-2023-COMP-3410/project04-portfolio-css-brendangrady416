/*
 * Brendan Grady
 *BadAvatarException works correctly with not major challenges.
 */

package hw3;

public class BadAvatarException extends Exception {
	public BadAvatarException(String message) {
		super (message);
	}

}
