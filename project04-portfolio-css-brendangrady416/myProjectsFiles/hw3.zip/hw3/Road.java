/*
 * Brendan Grady
 *Road works as intended, there were no issues 
 */

package hw3;

import edu.du.dudraw.Draw;

public class Road extends TerrainTile{
	
	public Road(GridPoint location) {
		super(location);
	}
	
	//override setColor from TerrainTile 
	public void setColor(Draw duDwin){
		duDwin.setPenColor(255, 255, 0);
	}

	@Override
	public void setVeg(int v) {
		return;
	}

}
