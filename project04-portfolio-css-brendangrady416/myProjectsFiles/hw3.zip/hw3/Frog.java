/*
 * Brendan Grady
 *Frog works as intended to display and correctly move the Frog avatar. The only issue came from
 * the Frog getting stuck in the corner while hopping in two square distances.  
 */

package hw3;

import java.util.List;

public class Frog extends Avatar{
	
	private int distance;

	protected Frog(int xLoc, int yLoc, TerrainMap tm) {
		super(xLoc, yLoc, tm);
		
	}

	//move the frog in random directions, avoiding mountains. The frog hops two square on land and swims
	// one square in water.
	public void move() {	
		List<GridPoint> surroundings = new GridPoint(xLoc, yLoc).getNeighbors(distance);
		System.out.println(surroundings);
		
		int moveAt = (int) Math.round(Math.random()*surroundings.size());
		for (int i=0; i< surroundings.size(); i++) {
			if (i ==  moveAt) {
				if (TerrainMap.theTiles.get(new GridPoint(surroundings.get(i).getX(), surroundings.get(i).getY())).getBumpy(null) == 0 ) {
					this.xLoc = surroundings.get(i).getX();
					this.yLoc = surroundings.get(i).getY();
					this.updateDistance();
					return;
				}
			}
		}
	}
	
	// move the frog two spaces on land and one space in water
	public void updateDistance() {
		if (TerrainMap.theTiles.get(new GridPoint(xLoc, yLoc)).getWet(null)<50 ) {
			distance = 2;
		}
		else if (TerrainMap.theTiles.get(new GridPoint(xLoc, yLoc)).getWet(null)>=50 ) {
			distance = 1;
		}	
	}

	//set the frog image 
	public String getImage() {
		return "hw3_frog.png";
	}
	

}
