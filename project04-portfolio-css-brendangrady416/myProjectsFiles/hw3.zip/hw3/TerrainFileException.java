/*
 * Brendan Grady
 *TerrainFileException works with no issues  
 */

package hw3;

public class TerrainFileException extends Exception{
	public TerrainFileException(String message) {
		super (message);
	}
}
