/*
 * Brendan Grady
 *Grass works as intended, there were no issues 
 */

package hw3;

import edu.du.dudraw.Draw;

public class Grass extends TerrainTile{
	
	private int vegetation;
	
	public Grass(GridPoint location) {
		super(location);
		this.vegetation = (int)(Math.random()*100);;
	}
	
	//override setColor from TerrainTile 
	public void setColor(Draw duDwin){
		duDwin.setPenColor(0, 250-vegetation, 0);
	}
	
	public int getVeg(Draw duDwin) {
		return this.vegetation;
	}
	
	public int getWet(Draw duDwin) {
		return 10;
	}
	
	public void setVeg(int x) {
		this.vegetation = x;
	}
	


}
