/*
 * Brendan Grady
 *Goat works as intended to display the cow image and set preferences. No big challenges. 
 */

package hw3;

public class Goat extends Grazer{
	
	protected Goat(int xLoc, int yLoc, TerrainMap tm) {
		super(xLoc, yLoc, tm);
	}
	
	//Set the goat image 
	public String getImage() {
		return "hw3_goat.png";
	}
	
	//allow the goat to travel on mountains 
	public int acceptRocky() {
		return 100;
	}

}
