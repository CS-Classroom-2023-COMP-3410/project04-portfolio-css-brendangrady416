/*
 * Brendan Grady
 *Water works as intended, there were no issues 
 */

package hw3;

import edu.du.dudraw.Draw;

public class Water extends TerrainTile{
	
	public Water(GridPoint location) {
		super(location);
	}
	
	//override setColor from TerrainTile 
	public void setColor(Draw duDwin){
		duDwin.setPenColor(0, 100, 255);
	}
	
	public int getWet(Draw duDwin){
		return 100;
	}

	@Override
	public void setVeg(int v) {
		return;
	}

} 
