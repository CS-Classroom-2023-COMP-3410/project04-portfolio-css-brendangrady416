/*
 * Brendan Grady
 *I could not get the DrawListener and reading the mouse clicks to function properly. This File does however
 * establish the Draw window and based on the input list of Avatars draw and animate all the animals. The only
 * issue was trying to get the mouse click to move the Human.
 */

package hw3;

import java.util.List;

import edu.du.dudraw.Draw;
import edu.du.dudraw.DrawListener;

public class SimWindow implements DrawListener{

	// Some static constants that everyone can use
	//   the represent the window size
	public final static int windowWidth = 1050;
	public final static int windowHeight = 700;

	private TerrainMap tm;
	private Draw duDwin;
	private DrawListener duDwinL;
	private List<Avatar> avas; 
	

	public SimWindow(TerrainMap tm, List<Avatar> avas) {

		// Setup the DuDraw window
		duDwin = new Draw("COMP2381 Animal Simulation"); // The OO version of DUDraw
		duDwin.setCanvasSize(SimWindow.windowWidth, SimWindow.windowHeight);
		duDwin.enableDoubleBuffering(); // Too slow otherwise -- need to use .show() later

		// Set the scale of the window
		// Right now it is set to match the pixels
		duDwin.setXscale(0, SimWindow.windowWidth);
		duDwin.setYscale(0, SimWindow.windowHeight);
		

		duDwin.addListener(duDwinL);

		this.tm = tm;
		this.avas = avas;	
	}

	//Clear the last screen and draw all avatars
	public void update() {
		// TODO: Clear the entire window to white and draw the TerrainMap
		duDwin.clear(255, 255, 255);
		tm.draw(duDwin);
		
		for (Avatar animal: this.avas) {
			animal.draw(duDwin);
		}

		duDwin.show();  // used in double buffering
	}

	//run the game loop and update the avatars 
	public void runSimulation() {
		// This is the main game loop
		update(); // Initial positing

		while(true) {

			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			//read mouse clicks and call process
			if (duDwin.isMousePressed() ) {
				this.mousePressed(duDwin.mouseX(), duDwin.mouseY());
				for (Avatar animal: this.avas) {
					animal.process( new GridPoint( (int)(duDwin.mouseX()/35) , (int)(duDwin.mouseY()/35) ) );
				}
			}
			
			//move each avatar
			for (Avatar animal: this.avas) {
				animal.move();
			}
			update();
		}	
	}

	
	@Override
	public void keyPressed(int arg0) {
		// TODO Auto-generated method stub
		return;
	}

	@Override
	public void keyReleased(int arg0) {
		// TODO Auto-generated method stub
		return;
	}

	@Override
	public void keyTyped(char arg0) {
		// TODO Auto-generated method stub
		return;
	}

	@Override
	public void mouseClicked(double arg0, double arg1) {
		// TODO Auto-generated method stub
		return;
	}

	@Override
	public void mouseDragged(double arg0, double arg1) {
		// TODO Auto-generated method stub
		return;
	}

	@Override
	public void mousePressed(double arg0, double arg1) {
		// TODO Auto-generated method stub
		return;
	}

	@Override
	public void mouseReleased(double arg0, double arg1) {
		// TODO Auto-generated method stub
		return;
	}
	
}