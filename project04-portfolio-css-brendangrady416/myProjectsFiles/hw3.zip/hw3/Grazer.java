/*
 * Brendan Grady
 *Grazer works as intended. Moves grazers towards the most vegitation first, then less veg, then 
 * no veg as the veg is more eaten. Only a small problem was moving the grazer after all
 *  the veg around it is gone.
 */

package hw3;

import java.util.List;


public abstract class Grazer extends Avatar {

	protected Grazer(int xLoc, int yLoc, TerrainMap tm) {
		super(xLoc, yLoc, tm);	
	}
	
	//move towards most vegitation first then less then no vegitation. Eat grass on that square. 
	public void move() {
		List<GridPoint> surroundings = new GridPoint(xLoc, yLoc).getNeighbors(1);
		System.out.println(surroundings);
		
		for (GridPoint point: surroundings ) {
			if (TerrainMap.theTiles.get(point).getBumpy(null)== this.acceptRocky() && TerrainMap.theTiles.get(point).getWet(null)<50 && TerrainMap.theTiles.get(point).getVeg(null) > 50) {
				this.xLoc = point.getX();
				this.yLoc = point.getY();
				this.eat();
				return;	
			}
		}
		for (GridPoint point: surroundings ) {
			if (TerrainMap.theTiles.get(point).getBumpy(null)== this.acceptRocky() && TerrainMap.theTiles.get(point).getWet(null)<50 && TerrainMap.theTiles.get(point).getVeg(null) > 0) {
				this.xLoc = point.getX();
				this.yLoc = point.getY();
				this.eat();
				return;
			}
		}
		int moveAt = (int) Math.round(Math.random()*surroundings.size());
		for (int i=0; i< surroundings.size(); i++) {
			if (i ==  moveAt) {
				if (TerrainMap.theTiles.get(new GridPoint(surroundings.get(i).getX(), surroundings.get(i).getY())).getBumpy(null)<= this.acceptRocky() && TerrainMap.theTiles.get(new GridPoint(surroundings.get(i).getX(), surroundings.get(i).getY() )).getWet(null)<50) {
					this.xLoc = surroundings.get(i).getX();
					this.yLoc = surroundings.get(i).getY();
					return;
				}
			}
		}
	}
		
	//decrease the level of vegitation, but do not go below 0
	public void eat() {
			TerrainMap.theTiles.get(new GridPoint(this.xLoc, this.yLoc)).setVeg(TerrainMap.theTiles.get(new GridPoint(this.xLoc, this.yLoc)).getVeg(null)-25);
			if (TerrainMap.theTiles.get(new GridPoint(this.xLoc, this.yLoc)).getVeg(null) < 0) {
				TerrainMap.theTiles.get(new GridPoint(this.xLoc, this.yLoc)).setVeg(0);
			}
		
	}
		
		
	public abstract String getImage();
	
	public abstract int acceptRocky();

}


