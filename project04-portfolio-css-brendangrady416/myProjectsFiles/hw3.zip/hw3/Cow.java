/*
 * Brendan Grady
 *Cow works as intended to display the cow image and set preferences. No big challenges. 
 */

package hw3;

public class Cow extends Grazer{
	
	protected Cow(int xLoc, int yLoc, TerrainMap tm) {
		super(xLoc, yLoc, tm);
	}
	
	//Set the cow image 
	public String getImage() {
		return "hw3_cow2.png";
	}
	
	//prevent the cow from traveling on rocks 
	public int acceptRocky() {
		return 0;
	}

}
