/*
 * Brendan Grady
 *Mountain works as intended, there were no issues 
 */

package hw3;

import edu.du.dudraw.Draw;

public class Mountain extends TerrainTile{
	
	private int vegetation;
	
	public Mountain(GridPoint location) {
		super(location);
		this.vegetation = (int)(Math.random()*50);
	}
	
	//override setColor from TerrainTile 
	public void setColor(Draw duDwin){
		duDwin.setPenColor(100, 50+vegetation, 100);
	}
	
	public int getBumpy(Draw duDwin){
		return 100;
	}
	
	public int getVeg(Draw duDwin) {
		return this.vegetation;
	}
	
	public void setVeg(int x) {
		this.vegetation = x;
	}


}