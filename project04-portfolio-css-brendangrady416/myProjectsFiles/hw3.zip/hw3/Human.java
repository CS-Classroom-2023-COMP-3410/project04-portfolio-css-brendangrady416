/*
 * Brendan Grady
 *Human is incomplete as I was never able to read the mouse clicks. This function would have
 * taken in a GridPoint from the mouse, set a path in the form of a list, and parce through
 *  that list to move one step at a time. 
 */

package hw3;

import java.util.List;

public class Human extends Avatar{

	private PathFinder pf;
	private GridPoint nextMove;

	protected Human(int xLoc, int yLoc, TerrainMap tm) {
		super(xLoc, yLoc, tm);
		 this.pf = new PathFinder(tm);
		 this.nextMove = new GridPoint(xLoc, yLoc);
	}

	//move the Human to the next desired square 
	public void move() {
		this.xLoc = this.nextMove.getX();
		this.yLoc = this.nextMove.getY();
	}

	//set the human image 
	public String getImage() {
		return "hw3_human.png";
	}
	
	//process takes in a GridPoint and makes a list of the GridPoints along the path based on findPath.
	// Move is then called on each point in the path list.
	public void process(GridPoint end) {
		List<GridPoint> path = this.pf.findPath(new GridPoint(this.xLoc, this.yLoc), end);
		for (GridPoint point: path) {
			this.nextMove = point;
			this.move();
			
		}
	}

}
